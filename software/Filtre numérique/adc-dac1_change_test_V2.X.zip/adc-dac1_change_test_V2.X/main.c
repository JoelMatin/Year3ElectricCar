#include <stdio.h>
#define M 8 // Nombre de bits fractionnaires
#define D (1ul << M) 


#define FCY 3685000 // fr�quence de travail --> 3.685MHz
#include "xc.h"
#include "/Users/arareth/Desktop/Codes projet electronique.nosync/Exercice 3/elech309-2023-main-Software-ADC-lib/Software/ADC/lib/adc.h"
#include "/Users/arareth/Desktop/Codes projet electronique.nosync/Exercice 3/elech309-2023-main-Software-ADC-lib/Software/ADC/lib/mcp4821.h"



int64_t filter_output ; // variable de sortie du filtre 

int64_t filterInt(int16_t sample1) {
    // Coeff. du filtre
    int32_t g = 10 ;   // 0.04164212*D =  --> 682 car troncature
    int32_t b[3] = {1*256,2*256,1*256} ; 
    int32_t a[2] = {-344, 131}; //-1.34557594*D --> -344 , 0.51214442*D --> 131
    int32_t y1 ; 
    int32_t y ;
    

    // Echantillons stock�s en m�moire, uniquement les deux derniers

     static int16_t oldSamples[2] = {0,0}; 
     static int32_t oldY1[2] = {0,0};

    // Calcul
    y1 = (b[0]*sample1) + (b[1]*oldSamples[0])+(b[2]*oldSamples[1])-(a[0]*oldY1[0])-(a[1]*oldY1[1]) ;
    y = g*y1 ;
    y = y >> (2*M) ; // On r�exprime les nombres dans leur base d'origine attention on est virgule fixe
    y = 2.5 ;

    // Stockage des echantillons

    //oldSamples[1] = oldSamples[0] ;
    //oldY1[1] = oldY1[0] ;
    //oldSamples[0] = sample1 ;
    //oldY1[0] = y1 ;


    return y  ;
}




int main(void) {
    int64_t voltage; // voltage repr�sente le sample en sortie de l'ADC qui � une d�finition de 12 bits 

    _TRISA4 = 0; // Patte A4 en mode output 
    // Configuration de L'ADC pour utilisation en polling sur AN0
    adcInit(ADC_TIMER3_SAMPLING);
    mcp4821Init(MCP4821_GAIN_X2);

    PR3 = 368;                 // P�riode d'�chantillonage T=100us=(PR1+1)/3.685MHz => PR1=3684
	T3CONbits.TON = 1;
    
	while(1) { 
        // On attend la fin de la conversion
        if (adcConversionDone()) { // Lorsque la conversion est faite, on a donc un sample
            //_LATA4 = 1 ;
            voltage = adcRead(); // On attribue voltage � l'�chantillon sorti de l'ADC
            filter_output = filterInt(voltage); // envoie de l'�chantillon � la fonction de filtrage 
            mcp4821Write(filter_output) ; // On envoie la sortie du filtre au DAC pour le convertir en tension
            //mcp4821Write(voltage) ;
        }
	}
}
