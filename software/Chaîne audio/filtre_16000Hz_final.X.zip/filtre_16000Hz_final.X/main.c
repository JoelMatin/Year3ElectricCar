#include "xc.h"
#include "adc.h"
#include "configuration.h"
#include "fskDetector.h"
#include "stdlib.h"
#include "stdio.h"
#define m 1024 // r�sultat de 2^10 --> n�cessaire pour ne pas avoir un coefficeint qui soit diff�rent de 0




// D�finition des coefficients --> via code Python fourni

// COEFFICIENTS 900 HZ --> obtenus via matlab
//parametre du premier �tage
    static int32_t b1[3] = {1 *m,2 * m , 1 * m} ;
    static int32_t a1[2] = { -1.86370006 * m,   0.98824962     * m} ;
    static int32_t g1 = 0.001771  * m ;
//parametre du deuxi�me �tage
    static int32_t b2[3] = {1 *m,2 * m , 1 * m} ;
    static int32_t a2[2] = { -1.86719114 * m,    0.98840267     * m} ;
    static int32_t g2 = 0.001726       * m ;
//parametre du troisi�me �tage
    static int32_t b3[3] = {1 *m,-2 * m , 1 * m} ;
    static int32_t a3[2] = { -1.86766577 * m,    0.99507105     * m} ;
    static int32_t g3 = 0.023       * m ;
//parametre du quatri�me �tage
    static int32_t b4[3] = {1 *m,-2 * m , 1 * m} ;
    static int32_t a4[2] = { -1.87591938 * m,    0.99522511     * m} ;
    static int32_t g4 = 0.02283       * m ;    
    
    
// COEFFICIENTS 1100 HZ --> obtenus via matlab
//parametre du premier �tage
    static int32_t b1p[3] = {1 *m,2 * m , 1 * m} ;
    static int32_t a1p[2] = { -1.80081358   * m, 0.98565917       * m} ;
    static int32_t g1p = 0.002661         * m ;
//parametre du deuxi�me �tage
    static int32_t b2p[3] = {1 *m,2 * m , 1 * m} ;
    static int32_t a2p[2] = {-1.80592184  * m, 0.98584165             * m} ;
    static int32_t g2p = 0.00259        * m ;
//parametre du troisi�me �tage
    static int32_t b3p[3] = {1 *m,-2 * m ,1 * m} ;
    static int32_t a3p[2] = { -1.8047745 * m, 0.99398116              * m} ;
    static int32_t g3p = 0.02277         * m ;
//parametre du quatri�me �tage
    static int32_t b4p[3] = {1 *m,-2 * m , 1 * m} ;
    static int32_t a4p[2] = {-1.8169234  * m, 0.99416513        * m} ;
    static int32_t g4p = 0.02273  * m ;
    
// Fonction qui fait le calcul de y    
int32_t filtre(int32_t b[],int32_t a[], int32_t x[] , int32_t y[]) {
    y[0] = (x[0]*b[0])+ (x[1]*b[1])+(x[2]*b[2])-(y[1]*a[0]+y[2]*a[1]) ; //y[0] est la valeur courante, y[1] la valeur pr�cedente
    y[0]= y[0]/m ; 
    return y[0] ;
}


int main(void) {
    frcPll40MHzConfig(); // On travail en 40MHz
    unsigned int sample, j;
    int msg ;
    //unsigned int data[6400];
    
    // Ici on va inicier nos diff�rentes variables pour 900 Hz
    int32_t y1_In[3] = {0}; //In est la vapeur en sortie de bloc du filtre avant de passer dans le bloc gain
    int32_t y1_Out[3] = {0} ; // Out est la valeur de y apr�s �tre pass� dans le bloc de gain
    int32_t y2_In[3] = {0}; 
    int32_t y2_Out[3] = {0} ;
    int32_t y3_In[3] = {0}; 
    int32_t y3_Out[3] = {0} ;
    int32_t y4_In[3] = {0}; 
    int32_t y4_Out = 0 ; // y4 n'est plus un �chantillons dont on doit garder ses valeurs pr�centes en m�moire
    int32_t x[3] = {0}; // Ici seront stock�s les �chantillons
    
    // Ici on va inicier nos diff�rentes variables pour 1100 Hz
    int32_t z1_In[3] = {0}; //In est la vapeur en sortie de bloc du filtre avant de passer dans le bloc gain
    int32_t z1_Out[3] = {0} ; // Out est la valeur de y apr�s �tre pass� dans le bloc de gain
    int32_t z2_In[3] = {0}; 
    int32_t z2_Out[3] = {0} ;
    int32_t z3_In[3] = {0}; 
    int32_t z3_Out[3] = {0} ;
    int32_t z4_In[3] = {0}; 
    int32_t z4_Out = 0 ; // y4 n'est plus un �chantillons dont on doit garder ses valeurs pr�centes en m�moire
    
     
    // Configuration de L'ADC pour utilisation en polling sur AN0
    adcInit(ADC_TIMER3_SAMPLING);
    PR3 = 2499;                 // T=200�s=(PR1+1)/3.685MHz => PR1+1=737 --> pour 16kHz

        /* Configuration du Peripheral Pin Select (PPS) pour connecter le signal
     * Rx de l'UART1 � RB6/RP6 et le signal Tx � RB7/RP7 */
	_U1RXR = 6;    // U1RX -> RP6
	_RP7R = 3;     // RP7 -> U1Tx

    // Configuration de l'UART1 avec un format de trame 8N1, � 57600 bits/s
    U1MODEbits.PDSEL = 0;       // 8 bits, pas de parit�
    U1MODEbits.STSEL = 0;       // 1 stop bit
    /* L'UART peut fonctionner � 2 vitesses diff�rentes. Le mode "high speed" 
     * est plus sensible au bruit et ne doit donc �tre utilis� que pour
     * des d�bits trop rapides pour le mode standard 
     * En mode standard, le d�bit est donn� par :
     * baud rate = FCY / (16*(U1BRG+1) 
     * => U1BRG = (3.685MHz / (16*57.6kHz)) - 1  =  2.998*/
    U1MODEbits.BRGH = 0;
    U1BRG = 10;
    
    U1MODEbits.UARTEN = 1;      // on active l'UART
    U1STAbits.UTXEN = 1;        // on active l'�mission
    
    
    int detLow ;    
    int detHigh ; 
    T3CONbits.TON = 1; 

	while(1) {      
                    while (!adcConversionDone()) {}  // en "pollant" l'ADC
                    _LATB15 = !_LATB15;
                    sample = adcRead();           // on ram�ne le r�sultat sur 8 bits
                    x[0] = sample ;
                    //compteur++ ;
                    
                    //Choix entre 900 ou 1100 Hz
                    y1_In[0] = filtre(b1,a1,x,y1_In) ;
                    y1_Out[0] = (y1_In[0]*g1)/m ;
                    y2_In[0] = filtre(b2,a2,y1_Out,y2_In) ;
                    y2_Out[0] = (y2_In[0]*g2)/m ;
                    y3_In[0] = filtre(b3,a3,y2_Out,y3_In) ;
                    y3_Out[0] = (y3_In[0]*g3)/m ;
                    y4_In[0] = filtre(b4,a4,y3_Out,y4_In) ;
                    y4_Out = (y4_In[0]*g4)/m ;
                    if(abs(y4_Out)>3){ detLow = 1 ;}
                    if(abs(y4_Out)<3){ detLow = 0 ;}
                   
                    
                    
                    //1100 Hz
                    z1_In[0] = filtre(b1p,a1p,x,z1_In) ;
                    z1_Out[0] = (z1_In[0]*g1p)/m ;
                    z2_In[0] = filtre(b2p,a2p,z1_Out,z2_In) ;
                    z2_Out[0] = (z2_In[0]*g2p)/m ;
                    z3_In[0] = filtre(b3p,a3p,z2_Out,z3_In) ;
                    z3_Out[0] = (z3_In[0]*g3p)/m ;
                    z4_In[0] = filtre(b4p,a4p,z3_Out,z4_In) ;
                    z4_Out = (z4_In[0]*g4p)/m ;
                    //if(abs(z4_Out)>3 && compteur<1600){ comptage1100 ++ ;}
                    if(abs(z4_Out)>3 ){ detHigh = 1 ;}
                    if(abs(z4_Out)<3 ){ detHigh = 0 ;}
                    //while(U1STAbits.UTXBF){}
                    //U1TXREG = 53;

                    
                    msg = fskDetector(detLow,detHigh) ;
                    if(msg){       
                            int ordre = msg>>8;
                            for (int i = 0; i <2; i++) {
                            char c = ((ordre >> (1 - i))& 1 ) + '0';
                            while(U1STAbits.UTXBF){}
                            U1TXREG = c;
                            }
                            int param = (msg&0xFF);
                            for (int i = 0; i <8; i++) {
                            char d = ((param >> (7 - i))& 1 ) + '0';
                            while(U1STAbits.UTXBF){}
                            U1TXREG = d;
                            }
                            
                            msg = 0 ;
                            param = 0;
                            ordre = 0;   
                    
                    }
                    
                    
                    // Une fois l'envoi effectu�, on mets � jour les �chantillons
                    x[2]=x[1] ;
                    x[1] = x[0] ;
                    // Pour 900Hz
                    for (j=2;j>0;j--){
                    y1_In[j] = y1_In[j-1] ;

                    y2_In[j] = y2_In[j-1] ;
 
                    y3_In[j] = y3_In[j-1] ;

                    y4_In[j] = y4_In[j-1] ;

                    y1_Out[j] = y1_Out[j-1] ;

                    y2_Out[j] = y2_Out[j-1] ;

                    y3_Out[j] = y3_Out[j-1] ;
                    
                     // Pour 1100 Hz
                    z1_In[j] = z1_In[j-1] ;

                    z2_In[j] = z2_In[j-1] ;
 
                    z3_In[j] = z3_In[j-1] ;

                    z4_In[j] = z4_In[j-1] ;

                    z1_Out[j] = z1_Out[j-1] ;

                    z2_Out[j] = z2_Out[j-1] ;

                    z3_Out[j] = z3_Out[j-1] ;
                    }

                }  
                    
            }
        
