/* 
 * File:   configuration.h
 * Author: mosee
 *
 * Created on 08 March 2021, 09:42
 */

#ifndef CONFIGURATION_H
#define	CONFIGURATION_H

void frcPll40MHzConfig(void);

#endif	/* CONFIGURATION_H */
